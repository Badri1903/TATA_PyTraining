# list of numbers divisible by 8

print([d for d in range(1, 1001) if d%8==0])