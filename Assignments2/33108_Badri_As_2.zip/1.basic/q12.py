# getting unique elements in a list

list_sample = [1,1,1,3,4,6,8,7,5,3,1,1,3,1,1,8,1,9,1,0,1,1,1,6,4,2,3,5,3]
for e in list_sample:
    for i in range(list_dup.count(a)):
        list_dup.remove(x\a)
print('Unique elements:', list_dup)

print('Sorted unique elements using set:', list(set(list_sample)))