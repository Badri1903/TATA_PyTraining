# Counting number of lists in a list of lists

nes_list = [[300, 345], [225, 205, 285], [200, 305, 330, 405, 150], [145, 230, 298, 360, 215], [120, 150, 405], [225, 205, 285], [380, 450], [185, 205, 230, 120, 160], [105, 185, 250, 385, 180]]
print('Number of lists in the given list:', len(nes_list))