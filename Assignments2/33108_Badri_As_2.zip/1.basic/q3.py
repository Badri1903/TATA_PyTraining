# iteration over dictionaries

dic1 = {1:10, 2:20}
dic2 = {3:30, 4:40}
dic3 = {5:50, 6:60}

list_dic = [dic1, dic2, dic3]

for d in list_dic:
    print(d)