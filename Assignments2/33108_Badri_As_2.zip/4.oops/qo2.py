# create a class Vehicle with no variables and methods

class Vehicle:
    pass