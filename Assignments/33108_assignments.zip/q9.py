def decoration(item, price):
    print("{0:<40}{1:>20}".format(item, price))
print("="*60)
decoration("item", "price")
print("="*60)
decoration("Apple", 150)
decoration("Chocolate", 200)
print("="*60)