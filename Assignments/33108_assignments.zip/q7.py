n = 6
element = 1
for i in range(0, n):
    print(element)
    for j in str(a):
        print(j, end=" ")
    print("")
print('\n\n')